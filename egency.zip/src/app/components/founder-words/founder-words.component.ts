import { Component } from '@angular/core';

@Component({
  selector: 'app-founder-words',
  imports: [],
  templateUrl: './founder-words.component.html',
  styleUrl: './founder-words.component.css'
})
export class FounderWordsComponent {

}
