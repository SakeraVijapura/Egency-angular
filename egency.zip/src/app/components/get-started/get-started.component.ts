import { Component } from '@angular/core';
import { BtnComponent } from "../btn/btn.component";

@Component({
  selector: 'app-get-started',
  imports: [BtnComponent],
  templateUrl: './get-started.component.html',
  styleUrl: './get-started.component.css'
})
export class GetStartedComponent {

}
