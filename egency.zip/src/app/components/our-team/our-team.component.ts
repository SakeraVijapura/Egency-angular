import { Component } from '@angular/core';

@Component({
  selector: 'app-our-team',
  imports: [],
  templateUrl: './our-team.component.html',
  styleUrl: './our-team.component.css'
})
export class OurTeamComponent {

}
