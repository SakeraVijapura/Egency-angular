import { Component } from '@angular/core';

@Component({
  selector: 'app-features-content',
  imports: [],
  templateUrl: './features-content.component.html',
  styleUrl: './features-content.component.css'
})
export class FeaturesContentComponent {

}
