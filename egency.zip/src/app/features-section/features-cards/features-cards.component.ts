import { Component } from '@angular/core';

@Component({
  selector: 'app-features-cards',
  imports: [],
  templateUrl: './features-cards.component.html',
  styleUrl: './features-cards.component.css'
})
export class FeaturesCardsComponent {

}
